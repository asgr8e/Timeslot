from flask import Flask, render_template, request, redirect, url_for, session
from datetime import datetime
import mysql.connector

app = Flask(__name__)
app.secret_key = 'your-secret-key'

# MySQL configuration
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="db2"
)

# Routes
@app.route('/')
def home():
    if 'username' in session:
        return redirect(url_for('homepage'))
    else:
        return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        cursor = db.cursor()
        cursor.execute("SELECT * FROM users WHERE username = %s AND password = %s", (username, password))
        user = cursor.fetchone()
        if user:
            session['username'] = username
            return redirect(url_for('homepage'))
        else:
            error = 'Invalid credentials. Please try again.'
            return render_template('login.html', error=error)
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        cursor = db.cursor()
        cursor.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, password))
        db.commit()
        session['username'] = username
        return redirect(url_for('homepage'))
    return render_template('register.html')

@app.route('/homepage', methods=['GET', 'POST'])
def homepage():
    if 'username' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        date = request.form['date']
        slot = request.form['slot']
        username = session['username']
        cursor = db.cursor()
        cursor.execute("INSERT INTO bookings (username, date, slot) VALUES (%s, %s, %s)", (username, date, slot))
        db.commit()

    cursor = db.cursor()
    cursor.execute("SELECT date, slot, username FROM bookings")
    booked_slots = cursor.fetchall()
    
    return render_template('homepage.html', booked_slots=booked_slots)

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
